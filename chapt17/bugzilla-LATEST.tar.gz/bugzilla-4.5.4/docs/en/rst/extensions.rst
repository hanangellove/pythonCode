Extensions
==========

Your Bugzilla installation has the following extensions available (as of the
last time you compiled the documentation):

.. toctree::
   :maxdepth: 1
   :glob:
   
   extensions/*
