.. Bugzilla documentation master file, created by
   sphinx-quickstart on Tue Sep  3 16:11:00 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Bugzilla Documentation
======================

.. toctree::
   :maxdepth: 3
   :numbered:

   about
   installation
   administration
   security
   using
   extensions
   customization
   patches
   troubleshooting
   modules
   gfdl
